import React, { useState } from "react";

function OrderForm({ onOrderAdded }) {
  const [orderId, setorderId] = useState("");
  const [deliveryDate, setdeliveryDate] = useState("");
  const [deliveryAddress, setdeliveryAddress] = useState("");
  const [deliveryFee, setdeliveryFee] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    const newOrder = { orderId, deliveryDate, deliveryAddress, deliveryFee };

    fetch("http://localhost:9000/orders", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(newOrder),
    })
      .then((response) => response.json())
      .then((data) => {
        onOrderAdded();
      })
      .catch((error) => console.error("Error adding order:", error));

    setorderId("");
    setdeliveryDate("");
    setdeliveryAddress("");
    setdeliveryFee("");
  };

  return (
    <div>
      <h2>Add Order</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>order id:</label>
          <input
            type="number"
            value={orderId}
            onChange={(e) => setorderId(e.target.value)}
            required
          />
        </div>
        <div>
          <label>deliveryDate:</label>
          <input
            type="date"
            value={deliveryDate}
            onChange={(e) => setdeliveryDate(e.target.value)}
            required
          />
        </div>
        <div>
          <label>deliveryAddres</label>
          <input
            type="text"
            value={deliveryAddress}
            onChange={(e) => setdeliveryAddress(e.target.value)}
            required
          />
        </div>
        <div>
          <label>deliveryFee</label>
          <input
            type="number"
            value={deliveryFee}
            onChange={(e) => setdeliveryFee(e.target.value)}
            required
          />
        </div>

        <button type="submit">Add Product</button>
      </form>
    </div>
  );
}

export default OrderForm;
