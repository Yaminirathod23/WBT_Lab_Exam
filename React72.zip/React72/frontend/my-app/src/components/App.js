import { Outlet } from "react-router-dom";
import React, { useState } from "react";
import OrderForm from "./OrderForm";
import OrderList from "./OrderList";

function App() {
  const [refresh, setRefresh] = useState(false);

  const handleOrderAdded = () => {
    setRefresh(!refresh);
  };

  return (
    <div>
      <OrderForm onOrderAdded={handleOrderAdded} />
      <OrderList refresh={refresh} />
    </div>
  );
}

export default App;
