import React, { useState, useEffect } from "react";

function OrderList() {
  const [Orders, setOrders] = useState([]);

  useEffect(() => {
    fetch("http://localhost:9000/orders")
      .then((response) => response.json())
      .then((data) => setOrders(data))
      .catch((error) => console.error("Error fetching orders:", error));
  }, []);

  return (
    <div>
      <h2>Orders List</h2>
      <table>
        <thead>
          <tr>
            <th>id</th>
            <th>date</th>
            <th>address</th>
            <th>fee</th>
          </tr>
        </thead>
        <tbody>
          {Orders.map((Orders) => (
            <tr key={Orders._id}>
              <td>{Orders.orderId}</td>
              <td>{Orders.deliveryDate}</td>
              <td>{Orders.deliveryAddress}</td>
              <td>{Orders.deliveryFee}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>

 
  );
}

export default OrderList;
